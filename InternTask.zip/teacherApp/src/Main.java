
import exercices.Exercise1;
import exercices.Exercise2;

import java.util.Map;
import java.sql.*;

public class Main {
    public static void main(String[] args) throws SQLException {


        Exercise2 task = new Exercise2();
        int gloves = task.countGlovesPairs(new int[]{1, 2, 1, 2, 1, 3, 2, 2, 1, 1});
        System.out.println("The count of pairs is " + gloves);

        Exercise1 secondTask = new Exercise1();
        Map wordsOccurrences = secondTask.getWordsOccurrences("Good Morning, Welcome to my store. My! Store is a grocery store morning welcome.");
        System.out.println(wordsOccurrences);


        // Enter data to the DB table with the following parameters
        MakeQuery query = new MakeQuery();
        query.enterRow("collections","ArrayList", "java.util", "This is ArrayList description");

        // Deleting a row from the DB table
        query.deleteRow("Collections", "ColectionID=3");

        // Print the information from the table
        ResultSet tableData = query.callRow("select * from collections");
        while (tableData.next()) {
            System.out.println(tableData.getString("ColectionID")+ " " + tableData.getString("ColectionName") + " " + tableData.getString("ColectionPackage")
                    + " " + tableData.getString("ColectionDescription"));

        }
    }
}