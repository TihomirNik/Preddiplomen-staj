import java.sql.*;

public class MakeQuery {

    ResultSet callRow(String selector) throws SQLException {

        Connection conection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test123", "tisho", "12345");
        Statement statement = conection.createStatement();

        return statement.executeQuery(selector);
    }


    boolean enterRow (String table,String  name, String inPackage,String text) throws SQLException {
        Connection conection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test123", "tisho", "12345");
        Statement statement = conection.createStatement();

        return statement.execute("INSERT INTO `test123`.`"+ table+"` (`ColectionName`, `ColectionPackage`, `ColectionDescription`) \n" +
                "VALUES ('"+name+"', '"+inPackage+"', '"+text+"');");

    }

    boolean deleteRow (String tableName, String condition) throws SQLException {
        Connection conection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test123", "tisho", "12345");
        Statement statement = conection.createStatement();

        return statement.execute(" DELETE FROM "+ tableName+" WHERE "+condition+";");

    }
    }
