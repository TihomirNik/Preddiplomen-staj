package colections;

public abstract class ColectionsDetails {
    private String name;
    private String inPackage;
    private String text;

  public ColectionsDetails(String name,String inPackage){
       this.name=name;
       this.inPackage=inPackage;
   }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
