package colections.list;

import colections.ColectionsDetails;

public class ArrayListInfo extends ColectionsDetails {
    private String base;

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    ArrayListInfo(String name, String inPackage) {
        super(name, inPackage);
    }
}
