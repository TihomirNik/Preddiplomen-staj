package colections.list;

import colections.ColectionsDetails;

public class LinkListInfo extends ColectionsDetails {
    private String base;

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    LinkListInfo(String name, String inPackage) {
        super(name, inPackage);
    }
}
