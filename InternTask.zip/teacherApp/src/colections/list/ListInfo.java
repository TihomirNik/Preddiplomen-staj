package colections.list;

import colections.ColectionsDetails;

import java.util.List;

public class ListInfo extends ColectionsDetails {
    private List<String> implementations;

    public List<String> getImplementations() {
        return implementations;
    }

    public void setImplementations(List<String> implementations) {
        this.implementations = implementations;
    }

    public ListInfo(String name, String inPackage) {
        super(name, inPackage);
    }

}
