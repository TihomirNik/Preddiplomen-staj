package colections.map;

import colections.ColectionsDetails;

public class HashMapInfo extends ColectionsDetails {
    private String base;

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    public HashMapInfo(String name, String inPackage) {
        super(name, inPackage);
    }


}
