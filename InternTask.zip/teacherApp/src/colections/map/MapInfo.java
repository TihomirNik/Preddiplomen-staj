package colections.map;

import colections.ColectionsDetails;

import java.util.List;

public class MapInfo extends ColectionsDetails {
    private List<String> implementations;

    public List<String> getImplementations() {
        return implementations;
    }

    public void setImplementations(List<String> implementations) {
        this.implementations = implementations;
    }

    MapInfo(String name, String inPackage) {
        super(name, inPackage);
    }
}