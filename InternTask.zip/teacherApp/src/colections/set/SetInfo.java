package colections.set;

import colections.ColectionsDetails;

import java.util.List;

public class SetInfo extends ColectionsDetails {
    private List<String> implementations;

    public List<String> getImplementations() {
        return implementations;
    }

    public void setImplementations(List<String> implementations) {
        this.implementations = implementations;
    }
    SetInfo(String name, String inPackage) {
        super(name, inPackage);
    }
}
