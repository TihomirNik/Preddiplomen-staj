package colections.set;

public class TreeSetInfo extends SetInfo {
    private String base;

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }
    TreeSetInfo(String name, String inPackage) {
        super(name, inPackage);
    }
}
