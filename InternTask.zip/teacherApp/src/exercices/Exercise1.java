package exercices;

import java.util.HashMap;
import java.util.Map;

     public class Exercise1 {
    public Map getWordsOccurrences(String text) {

        HashMap<String, Integer> map = new HashMap<>();
        String[] newText = text.split("\\W+");


        for (int i = 0; i < newText.length; i++) {
           String lowWord = newText[i].toLowerCase();
            if (map.containsKey(lowWord)) {
                map.put(lowWord, map.get(lowWord) + 1);
            } else {
                map.put(lowWord, 1);
            }
        }
        return map;
    }
}


