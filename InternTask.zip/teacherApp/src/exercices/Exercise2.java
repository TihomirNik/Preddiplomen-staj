package exercices;

import java.util.Arrays;

 public class Exercise2 {
    private int count;
    private int coupleOfGloves;

    public int countGlovesPairs(int[] ar) {
        Arrays.sort(ar);
        int number = ar[0];
        for (int i = 0; i < ar.length; i++) {
            if (number == ar[i]) {
                count++;
                if(count%2==0){
                    coupleOfGloves++;
                }
            } else {
                number = ar[i];
                count=1;
            }
        }

        return coupleOfGloves;
    }
}
